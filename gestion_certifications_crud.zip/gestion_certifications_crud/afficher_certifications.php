<?php
include 'connect.php';

echo "<a href='index.html'>Ajouter une nouvelle certification</a><br/><br/>";

$sql = "SELECT * FROM certifications";
$stmt = $pdo->prepare($sql);
$stmt->execute();
$certifications = $stmt->fetchAll();

echo "<table border='1'><tr><th>Nom</th><th>Prénom</th><th>Certification</th><th>Actions</th></tr>";
foreach ($certifications as $certification) {
    echo "<tr>";
    echo "<td>" . $certification['nom'] . "</td>";
    echo "<td>" . $certification['prenom'] . "</td>";
    echo "<td>" . $certification['certification'] . "</td>";
    echo "<td><a href='telecharger_certification.php?id=" . $certification['id'] . "'>Télécharger</a> | <a href='modifier_certification.php?id=" . $certification['id'] . "'>Modifier</a> | <a href='supprimer_certification.php?id=" . $certification['id'] . "'>Supprimer</a></td>";
    echo "</tr>";
}
echo "</table>";
?>